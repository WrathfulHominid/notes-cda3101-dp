
function ModuleDisplay()
{
	module_hide.forEach( (element) => { document.querySelector(element).classList.add("nulldisplay"); } );
}
